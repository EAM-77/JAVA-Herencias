/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import entidad.Estudiante;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author A300593
 */
public class EstudianteService {
    
   // Matriculación de un estudiante en un nuevo curso.
    
    public void inscripcion_aCurso(Estudiante e) {
         Scanner leer = new Scanner(System.in).useDelimiter("\n");
       // Matriculación de un estudiante en un nuevo curso
        ArrayList<String> listTemp = e.getCurso();
       
       String[] Cursos = {"Taller Literario" , "Matematica Aplicada " ," Programacion" , " Ingles Tecnico "};
       
        System.out.println(" Inscripcion a  Nuevo Curso\n");
        for (int i = 0; i < Cursos.length; i++) {
            System.out.println((i+1) + " - "+ Cursos[i] );
           
        }
        
    
        int op = leer.nextInt() - 1;
        do {

            // mejorar
            if (op >= 0 && op <= 3) {
           listTemp.add(Cursos[op]);
           e.setCurso(listTemp);
           
            } else {
                System.out.println("El valor ingresado no es valido ... vuelva a intentarlo");
            }
            op = leer.nextInt() - 1;

        } while (op < 0 || op > 3);

       
        
        
    }
}
