package Service;

import entidad.Persona;
import java.util.Scanner;

public class PersonaService {

    public void cambiarEstadoCivil(Persona p) {
        // Cambio del estado civil de una persona.

        Scanner leer = new Scanner(System.in);
        System.out.println("El estado actual es " + p.getEstadoCivil());
        String[] estCivil = {"Soltero", "Union libre", "Union de Hecho", "Casado", "Divorciado", "Viudo"};

        System.out.println("Ingrese el nuevo estado civil");
        System.out.println("1- Soltero");
        System.out.println("2- Union libre");
        System.out.println("3- Union de Hecho");
        System.out.println("4- Casado");
        System.out.println("5- Divorciado");
        System.out.println("6-Viudo");

        int op = leer.nextInt() - 1;
        do {

            // mejorar
            if (op >= 0 && op <= 5) {
                p.setEstadoCivil(estCivil[op]);
            } else {
                System.out.println("Estado incorrecto .. vuelva a intentarlo");
            }
            op = leer.nextInt() - 1;

        } while (op < 0 || op > 5);

    }

}
