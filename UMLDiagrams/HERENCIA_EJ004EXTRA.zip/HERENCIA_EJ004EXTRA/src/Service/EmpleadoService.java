/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import entidad.Empleado;
import java.util.Scanner;

/**
 *
 * @author A300593
 */
public class EmpleadoService {
    
    
   // Reasignación de despacho a un empleado.
    
    public void reasignarDespacho( Empleado e){
        
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        System.out.println(e.getApellido() + e.getNombre() +" se encuentra en el despacho " + e.getNumDespacho());
       
        System.out.println("Ingrese el num de desp a Asignar");
        e.setNumDespacho(leer.nextInt());
        
        
        
    }
    
}
