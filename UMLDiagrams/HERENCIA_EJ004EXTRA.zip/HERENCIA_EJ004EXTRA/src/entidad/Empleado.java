/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author A300593
 */
public class Empleado extends Persona {

protected String tipoFuncion;
protected Integer anioIncorp;
protected Integer numDespacho;

    public Empleado(String tipoFuncion, Integer anioIncorp, Integer numDespacho) {
        this.tipoFuncion = tipoFuncion;
        this.anioIncorp = anioIncorp;
        this.numDespacho = numDespacho;
    }

    public Empleado(String tipoFuncion, Integer anioIncorp, Integer numDespacho, String Nombre, String Apellido, Integer id, String estadoCivil) {
        super(Nombre, Apellido, id, estadoCivil);
        this.tipoFuncion = tipoFuncion;
        this.anioIncorp = anioIncorp;
        this.numDespacho = numDespacho;
    }

    public String getTipoFuncion() {
        return tipoFuncion;
    }

    public void setTipoFuncion(String tipoFuncion) {
        this.tipoFuncion = tipoFuncion;
    }

    public Integer getAnioIncorp() {
        return anioIncorp;
    }

    public void setAnioIncorp(Integer anioIncorp) {
        this.anioIncorp = anioIncorp;
    }

    public Integer getNumDespacho() {
        return numDespacho;
    }

    public void setNumDespacho(Integer numDespacho) {
        this.numDespacho = numDespacho;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
       
        sb.append("tipoFuncion=").append(tipoFuncion);
        sb.append(", anioIncorp=").append(anioIncorp);
        sb.append(", numDespacho=").append(numDespacho);
    
        return sb.toString();
    }


}
