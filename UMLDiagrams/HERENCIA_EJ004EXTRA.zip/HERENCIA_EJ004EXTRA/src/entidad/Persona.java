/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author A300593
 */
public abstract class Persona {

        
        protected String Nombre;
        protected String Apellido;
        protected Integer id;
        protected String estadoCivil;

    public Persona() {
    }

        
    public Persona(String Nombre, String Apellido, Integer id, String estadoCivil) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.id = id;
        this.estadoCivil = estadoCivil;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
      
        sb.append("Nombre=").append(Nombre);
        sb.append(", Apellido=").append(Apellido);
        sb.append(", id=").append(id);
        sb.append(", estadoCivil=").append(estadoCivil);
        sb.append('}');
        return sb.toString();
    }
        
        
}
