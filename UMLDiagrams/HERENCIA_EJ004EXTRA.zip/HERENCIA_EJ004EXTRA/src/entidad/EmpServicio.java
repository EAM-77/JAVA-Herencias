/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author A300593
 */
public class EmpServicio extends Empleado{
    
    private String Seccion;

    public EmpServicio(String Seccion, String tipoFuncion, Integer anioIncorp, Integer numDespacho, String Nombre, String Apellido, Integer id, String estadoCivil) {
        super(tipoFuncion, anioIncorp, numDespacho, Nombre, Apellido, id, estadoCivil);
        this.Seccion = Seccion;
    }

    public String getSeccion() {
        return Seccion;
    }

    public void setSeccion(String Seccion) {
        this.Seccion = Seccion;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Seccion=").append(Seccion);
     
        return sb.toString();
    }
    
    
}
