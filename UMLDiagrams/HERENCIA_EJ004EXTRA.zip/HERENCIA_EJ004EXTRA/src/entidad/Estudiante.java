/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

import java.util.ArrayList;

/**
 *
 * @author A300593
 */
public class Estudiante extends Persona {
    
    private ArrayList <String>  Curso;

    public Estudiante(ArrayList<String> Curso) {
        this.Curso = Curso;
    }

    public Estudiante(ArrayList<String> Curso, String Nombre, String Apellido, Integer id, String estadoCivil) {
        super(Nombre, Apellido, id, estadoCivil);
        this.Curso = Curso;
    }

    public ArrayList<String> getCurso() {
        return Curso;
    }

    public void setCurso(ArrayList<String> Curso) {
        this.Curso = Curso;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Curso=").append(Curso);
        
        return sb.toString();
    }

 
    
    
    
}
