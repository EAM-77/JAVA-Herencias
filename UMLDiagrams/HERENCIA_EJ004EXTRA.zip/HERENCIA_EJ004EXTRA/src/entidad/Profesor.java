/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author A300593
 */
public class Profesor extends Empleado {
 
    private String Depatamento;

    public Profesor(String Depatamento, String tipoFuncion, Integer anioIncorp, Integer numDespacho) {
        super(tipoFuncion, anioIncorp, numDespacho);
        this.Depatamento = Depatamento;
    }

    public Profesor(String Depatamento, String tipoFuncion, Integer anioIncorp, Integer numDespacho, String Nombre, String Apellido, Integer id, String estadoCivil) {
        super(tipoFuncion, anioIncorp, numDespacho, Nombre, Apellido, id, estadoCivil);
        this.Depatamento = Depatamento;
    }

    public String getDepatamento() {
        return Depatamento;
    }

    public void setDepatamento(String Depatamento) {
        this.Depatamento = Depatamento;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Depatamento=").append(Depatamento);
      
        return sb.toString();
    }
    
    
}
